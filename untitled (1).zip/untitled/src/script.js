
function addone() {
  add += 1;
  var test = document.getElementById("test");
  test.textContent = add;
}
